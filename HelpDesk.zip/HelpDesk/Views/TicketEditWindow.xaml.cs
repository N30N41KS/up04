﻿using HelpDesk.Models;
using System.Windows;
using System.Windows.Controls;

namespace HelpDesk.Views
{
    public partial class TicketEditWindow : Window
    {
        private readonly Ticket ticket;

        public TicketEditWindow(Ticket ticket)
        {
            InitializeComponent();

            this.ticket = ticket;

            TicketNumberTextBlock.Text = "Заявка №: " + ticket.Id;

            SelectComboBoxValue(CategoryComboBox, ticket.Category);
            DescriptionTextBox.Text = ticket.Description;
            SelectComboBoxValue(PriorityComboBox, ticket.Priority);
            SelectComboBoxValue(StatusComboBox, ticket.Status);
        }

        // Выбирает в списке пункт с нужным текстом. Если такого пункта нет — добавляет его.
        private static void SelectComboBoxValue(ComboBox comboBox, string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            foreach (ComboBoxItem item in comboBox.Items)
            {
                if ((item.Content as string) == value)
                {
                    comboBox.SelectedItem = item;
                    return;
                }
            }

            ComboBoxItem newItem = new ComboBoxItem();
            newItem.Content = value;
            comboBox.Items.Add(newItem);
            comboBox.SelectedItem = newItem;
        }

        private static string GetSelectedText(ComboBox comboBox)
        {
            ComboBoxItem item = comboBox.SelectedItem as ComboBoxItem;

            if (item == null || item.Content == null)
            {
                return string.Empty;
            }

            return item.Content.ToString();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка категории
            if (CategoryComboBox.SelectedItem == null)
            {
                MessageBox.Show(
                    "Выберите категорию заявки.",
                    "Проверка данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // Проверка описания
            if (string.IsNullOrWhiteSpace(DescriptionTextBox.Text))
            {
                MessageBox.Show(
                    "Введите описание проблемы.",
                    "Проверка данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // Проверка приоритета
            if (PriorityComboBox.SelectedItem == null)
            {
                MessageBox.Show(
                    "Выберите приоритет заявки.",
                    "Проверка данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // Проверка статуса
            if (StatusComboBox.SelectedItem == null)
            {
                MessageBox.Show(
                    "Выберите статус заявки.",
                    "Проверка данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // Изменения применяются только к временным данным в памяти.
            ticket.Category = GetSelectedText(CategoryComboBox);
            ticket.Description = DescriptionTextBox.Text.Trim();
            ticket.Priority = GetSelectedText(PriorityComboBox);
            ticket.Status = GetSelectedText(StatusComboBox);

            MessageBox.Show(
                "Изменения применены к временным данным.\n" +
                "На следующих занятиях заявка будет изменяться в MS SQL Server.",
                "HelpDesk",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
