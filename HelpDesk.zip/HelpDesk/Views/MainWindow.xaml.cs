﻿using HelpDesk.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace HelpDesk.Views
{
    public partial class MainWindow : Window
    {
        // Временные тестовые данные. После подключения MS SQL Server будут заменены данными из БД.
        private List<Ticket> tickets;

        public MainWindow()
        {
            InitializeComponent();

            CurrentDateTextBlock.Text = "Сегодня: " + DateTime.Now.ToString("dd.MM.yyyy");

            tickets = new List<Ticket>
            {
                new Ticket
                {
                    Id = 1,
                    Category = "Сеть",
                    Description = "Нет доступа в Интернет",
                    Priority = "Высокий",
                    Status = "Новая",
                    CreatedAt = DateTime.Now
                },

                new Ticket
                {
                    Id = 2,
                    Category = "ПО",
                    Description = "Не запускается Microsoft Word",
                    Priority = "Средний",
                    Status = "В работе",
                    CreatedAt = DateTime.Now
                },

                new Ticket
                {
                    Id = 3,
                    Category = "Оборудование",
                    Description = "Не работает принтер",
                    Priority = "Низкий",
                    Status = "Выполнена",
                    CreatedAt = DateTime.Now
                },

                new Ticket
                {
                    Id = 4,
                    Category = "Периферия",
                    Description = "Принтер печатает с полосами",
                    Priority = "Средний",
                    Status = "Новая",
                    CreatedAt = DateTime.Now.AddDays(-1)
                },

                new Ticket
                {
                    Id = 5,
                    Category = "Учётная запись",
                    Description = "Не удаётся войти в учётную запись",
                    Priority = "Высокий",
                    Status = "Отклонена",
                    CreatedAt = DateTime.Now.AddDays(-2)
                }
            };

            TicketsDataGrid.ItemsSource = tickets;
            UpdateTicketsCount(tickets.Count);
        }

        // Поиск и фильтр работают совместно: заявка должна подойти под оба условия.
        private void ApplyFilters()
        {
            // Событие SelectionChanged срабатывает ещё во время InitializeComponent(),
            // когда список заявок не создан.
            if (tickets == null)
            {
                return;
            }

            string searchText = SearchTextBox.Text.Trim().ToLower();

            string selectedStatus = "Все";
            ComboBoxItem statusItem = StatusComboBox.SelectedItem as ComboBoxItem;
            if (statusItem != null && statusItem.Content != null)
            {
                selectedStatus = statusItem.Content.ToString();
            }

            var result = tickets
                .Where(ticket =>
                    (selectedStatus == "Все" || ticket.Status == selectedStatus) &&
                    (searchText == "" ||
                        ticket.Description.ToLower().Contains(searchText) ||
                        ticket.Category.ToLower().Contains(searchText) ||
                        ticket.Status.ToLower().Contains(searchText)))
                .ToList();

            TicketsDataGrid.ItemsSource = result;
            UpdateTicketsCount(result.Count);
        }

        private void UpdateTicketsCount(int count)
        {
            TicketsCountTextBlock.Text = "Заявок: " + count;
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            ApplyFilters();
        }

        private void StatusComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void ResetFilterButton_Click(object sender, RoutedEventArgs e)
        {
            SearchTextBox.Clear();

            StatusComboBox.SelectedIndex = 0;

            TicketsDataGrid.ItemsSource = tickets;
            UpdateTicketsCount(tickets.Count);
        }

        private void AddTicketButton_Click(object sender, RoutedEventArgs e)
        {
            TicketCreateWindow window = new TicketCreateWindow();
            window.Owner = this;
            window.ShowDialog();
        }

        private void EditTicketButton_Click(object sender, RoutedEventArgs e)
        {
            if (TicketsDataGrid.SelectedItem == null)
            {
                MessageBox.Show(
                    "Сначала выберите заявку.",
                    "Редактирование",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            Ticket selectedTicket =
                TicketsDataGrid.SelectedItem as Ticket;

            if (selectedTicket == null)
            {
                MessageBox.Show(
                    "Не удалось получить данные выбранной заявки.",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                return;
            }

            TicketEditWindow window =
                new TicketEditWindow(selectedTicket);

            window.Owner = this;

            bool? result = window.ShowDialog();

            if (result == true)
            {
                TicketsDataGrid.Items.Refresh();

                // Заново применяем поиск и фильтр, чтобы список и счётчик соответствовали изменениям.
                ApplyFilters();
            }
        }

        // Двойной щелчок по строке таблицы открывает редактирование заявки.
        private void TicketRow_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            EditTicketButton_Click(sender, e);
        }

        private void DeleteTicketButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем наличие выбранной строки
            if (TicketsDataGrid.SelectedItem == null)
            {
                MessageBox.Show(
                    "Выберите заявку для удаления.",
                    "Удаление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // Просим подтверждение
            MessageBoxResult result =
                MessageBox.Show(
                    "Вы действительно хотите удалить выбранную заявку?",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show(
                    "На следующих занятиях здесь будет выполняться " +
                    "удаление записи из MS SQL Server.",
                    "HelpDesk",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result =
                MessageBox.Show(
                    "Выйти из учётной записи?",
                    "HelpDesk",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            LoginWindow loginWindow =
                new LoginWindow();

            loginWindow.Show();

            Close();
        }
    }
}
