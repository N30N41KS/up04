﻿using System;

namespace HelpDesk.Models
{
    /// <summary>Заявка технической поддержки.</summary>
    public class Ticket
    {
        public int Id { get; set; }
        public string Category { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Priority { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}
